﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;
using System.Data;
using System.Data.SqlClient;

namespace $safeprojectname$.Controllers
{
    public class UserController : Controller
    {
        
        DBManager db = new DBManager();
        public void checkSession()
        {
            string id =Session["uid"]+ " ";
            if(id!=null && id!="")
            {

            }
            else
            {
                Response.Redirect("/Home/Login");
            }
            
        }
 

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult dashboard()
        {
            return View();
        }
        public ActionResult MyProfile()
        {
            checkSession();
            try
            {
             string id=Session["uid"]+"";
                if(id!="" && id!=null)
                {
                    string cmd="select * from tbl_registration where email='"+id+"'";
                    DataTable dt=db.DisplayAllRecords(cmd);
                    if(dt.Rows.Count>0)
                    {
                        ViewBag.name=dt.Rows[0]["name"];
                        ViewBag.email=dt.Rows[0]["email"];
                        ViewBag.mobile=dt.Rows[0]["mobile"];
                        ViewBag.img=dt.Rows[0]["pic"];
                    }
                }
                else
                 Response.Redirect("/Home/Login");
            }
                
            
            catch(Exception ex)
            {
                Response.Write("<script>alert('+ex.Message+')</Script>");
            }
            return View();
        }
        public ActionResult Feedback()
        {
            string id = Session["uid"] + "";
            if(id!=null && id!="")
            {

            }
            else
            {
                Response.Redirect("/Home/Login");
            }
            return View();
        }
        [HttpPost]
        public ActionResult Feedback(string txtrate,string txtmsg)
        {
            try
            {
                string id = Session["uid"] + "";
                if (id != null && id != "")
                {
                    string cmd = "insert into tbl_feedback values('" + id + "','" + txtrate + "'," + txtmsg + "'," + DateTime.Now.ToString() + "')";
                    if (db.MyInsertUpdateDelete(cmd))
                        Response.Write("<script>alert('Feedback submitted !')</script>");

                    else
                        Response.Write("<script>alert('Error !')</script>");
                }
                else
                {
                    Response.Redirect("/Home/Login");
                }
            }
            catch(Exception ex)
            {
                Response.Write("<script>alert('+ex.Message+')</script>");
            }
                return View();
            }
        public ActionResult Complain()
        {
            return View();        
        }
        [HttpPost]
        public ActionResult Complain(string tstmsg)
        {
            try
            {
                string id = Session["uid"] + "";
                if (id != null && id != "")
                {
                    string cmd = "insert into tbl_complain values('" + id + "','" + tstmsg + "','" + DateTime.Now.ToString() + "')";
                    if (db.MyInsertUpdateDelete(cmd))
                        Response.Write("<script>alert('complain submitted!')</script>");
                    else
                        Response.Write("<script>alert('unable to save !')</script> ");
                }
                else
                {
                    Response.Redirect("/Home/Login");

                }
            }

            catch (Exception ex)
            {
                Response.Write("<script> alert('" + ex.Message + "')</script>");
            }
            return View();
        }
    
        public ActionResult ChangePassword()
        {
            return View();
        }
        public ActionResult Viewnotification()
        {
            return View();
        }
        public ActionResult Logout()
        {
            string id = Session["uid"] + "";
            if(id!=null && id!="")
            {
                Session.Clear();
                Session.Abandon();
                Session.RemoveAll();
                Response.Redirect("/Home/Login");
            }
            else
            {
                Response.Redirect("/Home/Login");
            }
            return View();
        }
    }
}
