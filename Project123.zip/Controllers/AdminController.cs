﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;

using System.Data;
using System.Data.SqlClient;

namespace $safeprojectname$.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ViewContact()
        {
            return View();
        }
        public ActionResult ViewFeedback()
        {
            return View();
        }
        public ActionResult ViewComplain()
        {
            return View();
        }
        public ActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ChangePassword(string txtoldpass, string txtnewpass, string txtconfirmpass)
        {
            string id = Session["aid"] + "";
            if (id != null && id != "")
            {
                if (txtnewpass == txtconfirmpass)
                {
                    string cmd = "update tbl_login set password='" + txtnewpass + "'where userid='" + id + "'and password='" + txtoldpass + "'";
                    DBManager db = new DBManager();
                    if (db.MyInsertUpdateDelete(cmd))
                        Response.Write("<script>alert('password changed ');window.location.href='/Home/Login'</script>");
                    else
                        Response.Write("<script> alert('No change')</script>");
                }
                else
                {
                    Response.Write("<script>alert('New password and confirm password not match')</script>");

                }
            }
            else
            {
                Response.Redirect("/Home/Login");
            }
            return View();
        }
        public ActionResult Addnotification()
        {

            return View();
        }
        [HttpPost]
        public ActionResult Addnotification(string txtnoti, string txtnotification)
        {
            string cmd = "insert into tbl_notification values('" + txtnoti + "','" + txtnotification + "','" + DateTime.Now.ToString() + "')";
            DBManager db = new DBManager();
            if (db.MyInsertUpdateDelete(cmd))
                Response.Write("<script>alert('Add Notification Successfully')</script>");
            else
                Response.Write("<script>alert('unable to add')</script>");
            return View();
        }
        public ActionResult Logout()
        {
            return View();
        }
        public ActionResult ViewRegistration()
        {
            return View();
        }
        public ActionResult Complain_Response(string res)
        {
            string cmd = "select * from tbl_complain where cid='" + res + "'";
            DBManager db = new DBManager();
            DataTable dt = db.DisplayAllRecords(cmd);
            if (dt.Rows.Count > 0)
            {
                ViewBag.id = dt.Rows[0]["cid"];

            }
            return View();
        }
        [HttpPost]
        public ActionResult Complain_Response(string msg, string txtid)
        {
            try
            {
                string cmd = "insert into tbl_response values('" + txtid + "','" + DateTime.Now.ToString() + "','" + msg + "')";
                DBManager db = new DBManager();
                if (db.MyInsertUpdateDelete(cmd))
                    Response.Write("<script>alert('Response save !');window.location.href='/Admin/ViewComplain'</script>");
                else
                    Response.Write("<script>alert('Error !')</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            return View();
        }
        public ActionResult ViewResponse()
        {
            return View();
        }
    }
}
