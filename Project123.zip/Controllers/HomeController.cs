﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Aboutus()
        {
            return View();
        }
        public ActionResult Gallary()
        {
            return View();
        }

        public ActionResult Registration()
        {
            return View();
        }
        //code for registration
        [HttpPost]
        public ActionResult Registration(Registration re)
        {
            if (ModelState.IsValid)
            {
                if (re.ConfirmPassword == re.Password)
                {
                    string file = Path.Combine(Server.MapPath("../content/pic/"), re.pic.FileName);
                    re.pic.SaveAs(file);
                    string cmd = "Insert into tbl_Registration values('" + re.Name + "','" + re.Mobile + "','" + re.Email + "', '" + re.Password + "','" + re.ConfirmPassword + "','" + re.pic.FileName + "')";
                    string cmd2 = "Insert into tbl_Login values('" + re.Email + "','" + re.Password + "','User')";

                    DBManager db = new DBManager();
                    if (db.MyInsertUpdateDelete(cmd) && db.MyInsertUpdateDelete(cmd2))
                    {
                        Response.Write("<Script>alert('Registration successfully Done')</Script>");

                        ModelState.Clear();
                    }
                    else
                    {
                        Response.Write("<script>alert('server error ')</script>");
                    }
                }
                else
                {

                }
            }
                
            return View();
        }
        public ActionResult Events()
        {
            return View();
        }
        public ActionResult Login()
        {
            CaptchaCode cg = new CaptchaCode();
            ViewBag.cph = cg.MyCaptcha();
            return View();
        }
        public JsonResult Refresh()
        {
            CaptchaCode cg = new CaptchaCode();
            string msg = cg.MyCaptcha();
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult Login(Login lg,string txtcph,string txtcaptcha)
        {
            if(ModelState.IsValid)
            {
                if(txtcph==txtcaptcha)
                {
                    string type = "";
                    string cmd = "select * from tbl_login where  userid='" + lg.UserId + "'and password='" + lg.Password + "'";
                    DBManager db = new DBManager();
                    DataTable dt = db.DisplayAllRecords(cmd);//1
                    if(dt.Rows.Count>0)//1>0
                    {
                        type = dt.Rows[0]["type"] + "";
                        if ( type== "User")
                        {
                            Session["uid"] = lg.UserId;
                            Response.Redirect("/User/Index");
                            
                        }
                        else if(type=="admin")
                        {
                            Session["aid"] = lg.UserId;
                            Response.Redirect("/Admin/Index");

                        }
                        else
                        {
                            ViewBag.msg = "invalid type";
                        }
                    }
                    else
                    {
                        ViewBag.msg = "Invalid UserId or Password";
                    }
                    ModelState.Clear();
                }
                else
                {
                    Response.Write("<script>alert('Captcha Code Not match')</script>");
                }
            }
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Contact(Enquiry e)
        {
            if (ModelState.IsValid)
            {
                string cmd = "Insert into tbl_enquiry values('" + e.Name + " ','" + e.Email + " ','" + e.Mobile + "','" + e.Message + "','" + DateTime.Now.ToString() + "')";
                DBManager db = new DBManager();
                if (db.MyInsertUpdateDelete(cmd))
                {
                    Response.Write("<Script>alert('Enquiry successfully Done')</Script>");
                    ModelState.Clear();
                }
                else
                {
                    Response.Write("<script>alert('server error ')</script>");
                }
            }
            return View();
        }
    }
}

