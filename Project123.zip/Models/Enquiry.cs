﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace $safeprojectname$.Models
{
    public class Enquiry
    {
        [Required(ErrorMessage="Please Enter Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please Enter Email")]
        public string Email { get; set; }
        
        [Required(ErrorMessage = "Please Entr Mobile")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Please Enter Message")]
        public string Message { set; get; }
       
    }
}