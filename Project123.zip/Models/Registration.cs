﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class Registration
    {
        [Required(ErrorMessage = " Please Enter Name")]
        public string Name{ set; get; }

        [Required(ErrorMessage="Please Enter Email")]
        public string Email { set; get; }


        [Required(ErrorMessage = "Please Enter Mobile")]
        public string Mobile { set; get; }

        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { set; get; }

        [Required(ErrorMessage = "Please Enter Confirm Password")]
        public string ConfirmPassword { set; get; }

        [Required(ErrorMessage = "Please Enter pic")]
        public HttpPostedFileBase pic { set; get; }
       
    }
}