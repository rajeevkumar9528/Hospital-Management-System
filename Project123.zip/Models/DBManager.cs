﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace $safeprojectname$.Models
{
    public class DBManager
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2J5EC4S;Initial Catalog=project123;Integrated Security=true");
        public bool MyInsertUpdateDelete(string command)
        {
            SqlCommand cmd = new SqlCommand(command, con);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
                int n = cmd.ExecuteNonQuery();//1
            
            if (n > 0)
                return true;
            else
                return false;
        }
        //method for display records
        public DataTable DisplayAllRecords(string command)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter sa = new SqlDataAdapter(command, con);
            sa.Fill(dt);
            return dt;
        }
    }  
}