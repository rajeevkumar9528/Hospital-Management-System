﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class Login
    {
        [Required(ErrorMessage="Please Enter User Id")]
        public string UserId { get; set; }


        [Required(ErrorMessage="Please Enter Password")]
        public string Password { get; set; }

       
    }
}